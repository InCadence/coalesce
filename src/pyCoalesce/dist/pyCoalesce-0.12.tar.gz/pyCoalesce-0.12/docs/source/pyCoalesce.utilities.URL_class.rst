pyCoalesce.classes.URL\_class module
====================================

.. automodule:: pyCoalesce.utilities.URL_class
    :members:
    :undoc-members:
    :show-inheritance:
