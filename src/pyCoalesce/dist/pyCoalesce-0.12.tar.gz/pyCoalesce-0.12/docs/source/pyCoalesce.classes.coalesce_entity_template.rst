pyCoalesce.classes.coalesce\_entity\_template module
====================================================

.. automodule:: pyCoalesce.classes.coalesce_entity_template
    :members:
    :undoc-members:
    :show-inheritance:
