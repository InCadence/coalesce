pyCoalesce.classes.entity module
================================

.. automodule:: pyCoalesce.classes.entity
    :members:
    :undoc-members:
    :show-inheritance:
