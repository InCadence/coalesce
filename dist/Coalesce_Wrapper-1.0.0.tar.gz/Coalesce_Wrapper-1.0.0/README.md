Coalesce Wrapper

The Python wrapper supports the basic functions of Create, Read, Update and Delete. 
All of these functions are tailored for coalesece based servers.
These functions can be imported into separate projects, but can not be run directly from the 
request file itself. They can be run from the wrapper_runner file found in the main directory 
of the wrapper.

