pyCoalesce.coalesce\_request module
===================================

.. automodule:: pyCoalesce.coalesce_request
    :members:
    :undoc-members:
    :show-inheritance:
