pyCoalesce.classes.coalesce\_entity module
==========================================

.. automodule:: pyCoalesce.classes.coalesce_entity
    :members:
    :undoc-members:
    :show-inheritance:
