# -*- coding: utf-8 -*-
"""
Created on Fri Jul  6 11:59:23 2018

@author: dvenkat
"""
from tests_coalesce_request import *